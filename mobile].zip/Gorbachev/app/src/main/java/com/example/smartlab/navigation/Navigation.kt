package com.example.smartlab.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.smartlab.screens.LogIn
import com.example.smartlab.screens.PreLogIn
import com.example.smartlab.screens.SplashScreen

@Composable
fun Navigation() {
    val navController = rememberNavController()
    NavHost(navController = navController,

        startDestination = "splashScreen")
    {
        composable("splashScreen"){
            SplashScreen(navController)
        }
        composable("PreLogIn"){
            PreLogIn(navController)
        }
        composable("logInScreen"){
            LogIn(navController)
        }
    }
}